# counter-app
Simple flask app that counts web site visits and stored in a default Redis backend. Used in Docker Deep Dive book
